package com.example

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.with
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.RequestQuote
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.calculators.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val sharedPrefs = remember { context.getSharedPreferences("calcpro_prefs", Context.MODE_PRIVATE) }
            val systemDark = isSystemInDarkTheme()
            
            var isDarkMode by remember {
                mutableStateOf(sharedPrefs.getBoolean("dark_mode_enabled", systemDark))
            }

            MyApplicationTheme(darkTheme = isDarkMode) {
                MainAppNavigator(
                    isDarkMode = isDarkMode,
                    onToggleTheme = {
                        isDarkMode = !isDarkMode
                        sharedPrefs.edit().putBoolean("dark_mode_enabled", isDarkMode).apply()
                    }
                )
            }
        }
    }
}

sealed class Screen {
    object Splash : Screen()
    object Home : Screen()
    data class Calculator(val tool: CalculatorTool) : Screen()
}

enum class CalculatorTool(
    val title: String,
    val description: String,
    val icon: ImageVector,
    val category: String
) {
    BMI("BMI Calculator", "Body Mass Index & weight health check", Icons.Default.FitnessCenter, "Health"),
    AGE("Age Calculator", "Precise biological age & date metrics", Icons.Default.CalendarToday, "Health"),
    GPA("GPA Calculator", "Semester credit grade average points", Icons.Default.School, "General"),
    LOAN("Loan Calculator", "Payments & total interest amortization", Icons.Default.TrendingUp, "Finance"),
    EMI("EMI Calculator", "Equated monthly payments tracker", Icons.Default.Percent, "Finance"),
    SALARY("Salary Calculator", "Net income take-home pay check", Icons.Default.Payments, "Finance"),
    CALORIE("Calorie Calculator", "BMR & TDEE metabolic requirements", Icons.Default.Restaurant, "Health"),
    YOUTUBE("YouTube Money", "Estimated AdSense channel revenue", Icons.Default.PlayArrow, "Finance"),
    PERCENTAGE("Percentage", "Simple ratios, margins, & growth", Icons.Default.Percent, "General"),
    DISCOUNT("Discount", "Savings deal, tax cuts, & checkouts", Icons.Default.LocalOffer, "General"),
    VAT("VAT Calculator", "Inclusive/exclusive consumer tax", Icons.Default.ReceiptLong, "Finance"),
    INTEREST("Interest Calculator", "Simple & compounding yield growth", Icons.Default.AccountBalance, "Finance"),
    MORTGAGE("Mortgage", "PITI rates, property tax & insurance", Icons.Default.Home, "Finance"),
    TAX("Tax Calculator", "Estimated progressive bracket dues", Icons.Default.RequestQuote, "Finance"),
    TIP("Tip Calculator", "Split bills & dining tips headcounts", Icons.Default.Payments, "General"),
    CURRENCY("Currency Converter", "Fully offline rate exchange swaps", Icons.Default.CurrencyExchange, "General")
}

@OptIn(ExperimentalAnimationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun MainAppNavigator(
    isDarkMode: Boolean,
    onToggleTheme: () -> Unit
) {
    var backStack by remember { mutableStateOf(listOf<Screen>(Screen.Splash)) }
    val currentScreen = backStack.lastOrNull() ?: Screen.Home

    // Handle android physical back button
    BackHandler(enabled = backStack.size > 1) {
        backStack = backStack.dropLast(1)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            if (currentScreen !is Screen.Splash) {
                TopAppBar(
                    title = {
                        if (currentScreen is Screen.Home) {
                            Column {
                                Text(
                                    text = "CALCULATOR APP",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isDarkMode) Color(0xFF8896B0) else Color(0xFF475569),
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "CalcPro",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        brush = Brush.horizontalGradient(
                                            colors = listOf(Color(0xFF38BDF8), Color(0xFF6366F1))
                                        )
                                    )
                                )
                            }
                        } else {
                            Text(
                                text = when (currentScreen) {
                                    is Screen.Calculator -> currentScreen.tool.title
                                    else -> "CalcPro"
                                },
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    },
                    navigationIcon = {
                        if (currentScreen is Screen.Calculator) {
                            IconButton(onClick = { backStack = backStack.dropLast(1) }) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = onToggleTheme) {
                            Icon(
                                imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "Toggle Theme",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent,
                        scrolledContainerColor = Color.Transparent
                    )
                )
            }
        },
        bottomBar = {
            if (currentScreen !is Screen.Splash) {
                NavigationBar(
                    containerColor = if (isDarkMode) Color(0xFF0D1220) else Color(0xFFE2E8F0),
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = currentScreen is Screen.Home,
                        onClick = {
                            if (currentScreen !is Screen.Home) {
                                backStack = listOf(Screen.Home)
                            }
                        },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("Dashboard", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = if (isDarkMode) Color(0xFF8896B0) else Color(0xFF475569),
                            unselectedTextColor = if (isDarkMode) Color(0xFF8896B0) else Color(0xFF475569),
                            indicatorColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = {
                if (targetState is Screen.Calculator || targetState is Screen.Home) {
                    (slideInHorizontally { width -> width } + fadeIn()).with(
                        slideOutHorizontally { width -> -width } + fadeOut()
                    )
                } else {
                    fadeIn().with(fadeOut())
                }
            },
            modifier = Modifier.padding(innerPadding)
        ) { screen ->
            when (screen) {
                is Screen.Splash -> {
                    SplashScreen(onFinished = {
                        backStack = listOf(Screen.Home)
                    })
                }
                is Screen.Home -> {
                    HomeScreen(onSelectTool = { tool ->
                        backStack = backStack + Screen.Calculator(tool)
                    })
                }
                is Screen.Calculator -> {
                    Box(modifier = Modifier.fillMaxSize()) {
                        when (screen.tool) {
                            CalculatorTool.BMI -> BmiCalculatorScreen()
                            CalculatorTool.AGE -> AgeCalculatorScreen()
                            CalculatorTool.GPA -> GpaCalculatorScreen()
                            CalculatorTool.LOAN -> LoanCalculatorScreen()
                            CalculatorTool.EMI -> EmiCalculatorScreen()
                            CalculatorTool.SALARY -> SalaryCalculatorScreen()
                            CalculatorTool.CALORIE -> CalorieCalculatorScreen()
                            CalculatorTool.YOUTUBE -> YoutubeMoneyCalculatorScreen()
                            CalculatorTool.PERCENTAGE -> PercentageCalculatorScreen()
                            CalculatorTool.DISCOUNT -> DiscountCalculatorScreen()
                            CalculatorTool.VAT -> VatCalculatorScreen()
                            CalculatorTool.INTEREST -> InterestCalculatorScreen()
                            CalculatorTool.MORTGAGE -> MortgageCalculatorScreen()
                            CalculatorTool.TAX -> TaxCalculatorScreen()
                            CalculatorTool.TIP -> TipCalculatorScreen()
                            CalculatorTool.CURRENCY -> CurrencyConverterScreen()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val scale = remember { Animatable(0.5f) }
    val isDark = MaterialTheme.colorScheme.background.value == 0xFF04050A.toULong()

    LaunchedEffect(Unit) {
        scale.animateTo(
            targetValue = 1f,
            animationSpec = tween(
                durationMillis = 800,
                easing = LinearEasing
            )
        )
        delay(1000)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isDark) Color(0xFF04050A) else Color(0xFFF0F4FF)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.scale(scale.value)
        ) {
            // High-fidelity Neon Floating badge
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xFF38BDF8), Color(0xFF6366F1))
                        )
                    )
                    .border(
                        2.dp,
                        Color.White.copy(alpha = 0.5f),
                        RoundedCornerShape(24.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Calculate,
                    contentDescription = "Logo",
                    tint = Color.White,
                    modifier = Modifier.size(54.dp)
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "CalcPro",
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "PREMIUM OFFLINE SUITE",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = if (isDark) Color(0xFF8896B0) else Color(0xFF475569)
            )
        }
    }
}

@Composable
fun HomeScreen(onSelectTool: (CalculatorTool) -> Unit) {
    val isDark = MaterialTheme.colorScheme.background == Color(0xFF04050A)
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Aesthetic tracking label & headline
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "SELECT A TOOL",
            style = MaterialTheme.typography.labelSmall,
            color = if (isDark) Color(0xFF8896B0) else Color(0xFF475569),
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Bento Row 1: BMI (wide box) + LOAN & CURRENCY (column of 2 rows)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            BentoWideCard(
                tool = CalculatorTool.BMI,
                onClick = { onSelectTool(CalculatorTool.BMI) },
                modifier = Modifier.weight(1f)
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BentoRowCard(
                    tool = CalculatorTool.LOAN,
                    onClick = { onSelectTool(CalculatorTool.LOAN) },
                    modifier = Modifier.weight(1f)
                )
                BentoRowCard(
                    tool = CalculatorTool.CURRENCY,
                    onClick = { onSelectTool(CalculatorTool.CURRENCY) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Bento Row 2: AGE (tall box) + CALORIE (popular card)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            BentoTallCard(
                tool = CalculatorTool.AGE,
                onClick = { onSelectTool(CalculatorTool.AGE) },
                modifier = Modifier.weight(0.75f)
            )
            BentoPopularCard(
                tool = CalculatorTool.CALORIE,
                onClick = { onSelectTool(CalculatorTool.CALORIE) },
                modifier = Modifier.weight(1.25f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Bento Row 3: DISCOUNT (wide row) + GPA (wide row)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(84.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            BentoRowCard(
                tool = CalculatorTool.DISCOUNT,
                onClick = { onSelectTool(CalculatorTool.DISCOUNT) },
                modifier = Modifier.weight(1f)
            )
            BentoRowCard(
                tool = CalculatorTool.GPA,
                onClick = { onSelectTool(CalculatorTool.GPA) },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Bento Row 4: INTEREST (wide row) + TAX (wide row)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(84.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            BentoRowCard(
                tool = CalculatorTool.INTEREST,
                onClick = { onSelectTool(CalculatorTool.INTEREST) },
                modifier = Modifier.weight(1f)
            )
            BentoRowCard(
                tool = CalculatorTool.TAX,
                onClick = { onSelectTool(CalculatorTool.TAX) },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Bento Row 5: SALARY (wide box) + YOUTUBE & EMI (column of 2 rows)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            BentoWideCard(
                tool = CalculatorTool.SALARY,
                onClick = { onSelectTool(CalculatorTool.SALARY) },
                modifier = Modifier.weight(1f)
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BentoRowCard(
                    tool = CalculatorTool.YOUTUBE,
                    onClick = { onSelectTool(CalculatorTool.YOUTUBE) },
                    modifier = Modifier.weight(1f)
                )
                BentoRowCard(
                    tool = CalculatorTool.EMI,
                    onClick = { onSelectTool(CalculatorTool.EMI) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Bento Row 6: MORTGAGE (wide row) + VAT (wide row)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(84.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            BentoRowCard(
                tool = CalculatorTool.MORTGAGE,
                onClick = { onSelectTool(CalculatorTool.MORTGAGE) },
                modifier = Modifier.weight(1f)
            )
            BentoRowCard(
                tool = CalculatorTool.VAT,
                onClick = { onSelectTool(CalculatorTool.VAT) },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Bento Row 7: PERCENTAGE (tall card) + TIP (tall card)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            BentoTallCard(
                tool = CalculatorTool.PERCENTAGE,
                onClick = { onSelectTool(CalculatorTool.PERCENTAGE) },
                modifier = Modifier.weight(1f)
            )
            BentoTallCard(
                tool = CalculatorTool.TIP,
                onClick = { onSelectTool(CalculatorTool.TIP) },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun BentoWideCard(
    tool: CalculatorTool,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isDark = MaterialTheme.colorScheme.background == Color(0xFF04050A)
    val cardBg = if (isDark) Color(0xFF0D1220) else Color(0xFFFFFFFF)
    val borderColor = if (isDark) Color(0x1F38BDF8) else Color(0x120284C7)
    val iconBg = if (isDark) Color(0x1238BDF8) else Color(0x0A0284C7)
    val iconColor = if (isDark) Color(0xFF38BDF8) else Color(0xFF0284C7)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(cardBg)
            .border(1.dp, borderColor, RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .testTag("tool_card_${tool.name.lowercase()}")
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = tool.icon,
                    contentDescription = tool.title,
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )
            }
            Column {
                Text(
                    text = tool.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = tool.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isDark) Color(0xFF8896B0) else Color(0xFF475569),
                    lineHeight = 14.sp,
                    maxLines = 2
                )
            }
        }
    }
}

@Composable
fun BentoTallCard(
    tool: CalculatorTool,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isDark = MaterialTheme.colorScheme.background == Color(0xFF04050A)
    val cardBg = if (isDark) Color(0xFF0D1220) else Color(0xFFFFFFFF)
    val borderColor = if (isDark) Color(0x1F38BDF8) else Color(0x120284C7)
    val iconBg = if (isDark) Color(0x1238BDF8) else Color(0x0A0284C7)
    val iconColor = if (isDark) Color(0xFF38BDF8) else Color(0xFF0284C7)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(cardBg)
            .border(1.dp, borderColor, RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .testTag("tool_card_${tool.name.lowercase()}")
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = tool.icon,
                    contentDescription = tool.title,
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = tool.title.replace(" Calculator", "").replace(" Converter", ""),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = tool.category,
                style = MaterialTheme.typography.bodySmall,
                color = if (isDark) Color(0xFF8896B0) else Color(0xFF475569),
                fontSize = 10.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun BentoRowCard(
    tool: CalculatorTool,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isDark = MaterialTheme.colorScheme.background == Color(0xFF04050A)
    val cardBg = if (isDark) Color(0xFF0D1220) else Color(0xFFFFFFFF)
    val borderColor = if (isDark) Color(0x1F38BDF8) else Color(0x120284C7)
    val iconBg = if (isDark) Color(0x1238BDF8) else Color(0x0A0284C7)
    val iconColor = if (isDark) Color(0xFF38BDF8) else Color(0xFF0284C7)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(cardBg)
            .border(1.dp, borderColor, RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .testTag("tool_card_${tool.name.lowercase()}")
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = tool.icon,
                    contentDescription = tool.title,
                    tint = iconColor,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = tool.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = tool.category,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isDark) Color(0xFF8896B0) else Color(0xFF475569),
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
fun BentoPopularCard(
    tool: CalculatorTool,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isDark = MaterialTheme.colorScheme.background == Color(0xFF04050A)
    val cardBg = if (isDark) Color(0xFF0D1220) else Color(0xFFFFFFFF)
    val borderColor = if (isDark) Color(0x3F6366F1) else Color(0x224F46E5) // More prominent purple border
    
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(cardBg)
            .border(1.5.dp, borderColor, RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .testTag("tool_card_${tool.name.lowercase()}")
            .padding(18.dp)
    ) {
        // Decorative background blur glow at top right
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .size(100.dp)
                .graphicsLayer(translationX = 30f, translationY = -30f)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0x226366F1),
                            Color(0x006366F1)
                        )
                    )
                )
        )

        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Popular badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0x266366F1))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "POPULAR",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF6366F1),
                        fontSize = 9.sp,
                        letterSpacing = 0.5.sp
                    )
                }

                // Apple Emoji or Icon
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x1AFBBF24)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = tool.icon,
                        contentDescription = "Popular Tool",
                        tint = Color(0xFFFBBF24),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Column {
                Text(
                    text = tool.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = tool.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isDark) Color(0xFF8896B0) else Color(0xFF475569),
                    lineHeight = 14.sp
                )
            }
        }
    }
}
