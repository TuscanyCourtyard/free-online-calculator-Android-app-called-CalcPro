package com.example.calculators

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CalcTextField
import com.example.ui.components.FaqSection
import com.example.ui.components.FormulaBox
import com.example.ui.components.GlassCard
import com.example.ui.components.GradientButton
import com.example.ui.components.ResultCard
import com.example.ui.theme.ColorAmber
import com.example.ui.theme.ColorGreen
import com.example.ui.theme.ColorRose
import java.time.LocalDate
import java.time.Period
import java.time.temporal.ChronoUnit
import java.util.Locale

@Composable
fun BmiCalculatorScreen() {
    var weight by remember { mutableStateOf("") }
    var height by remember { mutableStateOf("") }
    var isMetric by remember { mutableStateOf(true) }
    var calculated by remember { mutableStateOf(false) }

    var bmiScore by remember { mutableStateOf("0.0") }
    var bmiCategory by remember { mutableStateOf("") }
    var categoryColor by remember { mutableStateOf(ColorGreen) }
    var idealWeightRange by remember { mutableStateOf("") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "BMI Calculator",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Metric / Imperial Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isMetric) MaterialTheme.colorScheme.primary else Color(0x1F8896B0))
                            .clickable { isMetric = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Metric (kg / cm)",
                            color = if (isMetric) Color.Black else MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (!isMetric) MaterialTheme.colorScheme.primary else Color(0x1F8896B0))
                            .clickable { isMetric = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Imperial (lbs / in)",
                            color = if (!isMetric) Color.Black else MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }

                CalcTextField(
                    value = weight,
                    onValueChange = { weight = it },
                    label = if (isMetric) "Weight (kg)" else "Weight (lbs)",
                    placeholder = if (isMetric) "e.g. 70" else "e.g. 154",
                    testTag = "bmi_weight"
                )

                CalcTextField(
                    value = height,
                    onValueChange = { height = it },
                    label = if (isMetric) "Height (cm)" else "Height (inches)",
                    placeholder = if (isMetric) "e.g. 175" else "e.g. 69",
                    testTag = "bmi_height"
                )

                GradientButton(
                    text = "Calculate BMI",
                    onClick = {
                        val w = weight.toDoubleOrNull() ?: 0.0
                        val h = height.toDoubleOrNull() ?: 0.0

                        if (w > 0 && h > 0) {
                            val score = if (isMetric) {
                                w / ((h / 100.0) * (h / 100.0))
                            } else {
                                (w / (h * h)) * 703
                            }

                            bmiScore = String.format(Locale.US, "%.1f", score)

                            when {
                                score < 18.5 -> {
                                    bmiCategory = "Underweight"
                                    categoryColor = ColorRose
                                }
                                score < 25.0 -> {
                                    bmiCategory = "Normal Weight"
                                    categoryColor = ColorGreen
                                }
                                score < 30.0 -> {
                                    bmiCategory = "Overweight"
                                    categoryColor = ColorAmber
                                }
                                else -> {
                                    bmiCategory = "Obese"
                                    categoryColor = ColorRose
                                }
                            }

                            val minIdeal = if (isMetric) {
                                18.5 * ((h / 100.0) * (h / 100.0))
                            } else {
                                (18.5 * (h * h)) / 703
                            }
                            val maxIdeal = if (isMetric) {
                                24.9 * ((h / 100.0) * (h / 100.0))
                            } else {
                                (24.9 * (h * h)) / 703
                            }

                            idealWeightRange = String.format(
                                Locale.US,
                                "%.1f - %.1f %s",
                                minIdeal,
                                maxIdeal,
                                if (isMetric) "kg" else "lbs"
                            )
                            calculated = true
                        }
                    },
                    testTag = "bmi_calc_btn"
                )
            }
        }

        if (calculated) {
            ResultCard(
                title = "Your BMI Score",
                mainValue = bmiScore,
                subDetails = listOf(
                    "Classification" to bmiCategory,
                    "Healthy Weight Range" to idealWeightRange
                ),
                badgeText = bmiCategory,
                badgeColor = categoryColor
            )
        }

        FormulaBox(
            formula = if (isMetric) "BMI = weight (kg) / height² (m)" else "BMI = (weight (lbs) / height² (in)) * 703",
            description = "Body Mass Index (BMI) is a standardized health classification based on weight and height ratios."
        )

        FaqSection(
            faqs = listOf(
                "What is a healthy BMI?" to "A BMI of 18.5 to 24.9 is considered normal/healthy for adults. Less than 18.5 is underweight, 25 to 29.9 is overweight, and 30+ is obese.",
                "Is BMI accurate for athletes?" to "BMI is a simple correlation tool and may overestimate body fat in athletes or individuals with high muscle mass."
            )
        )
    }
}

@Composable
fun CalorieCalculatorScreen() {
    var age by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }
    var height by remember { mutableStateOf("") }
    var genderIsMale by remember { mutableStateOf(true) }
    var isMetric by remember { mutableStateOf(true) }
    var activityIndex by remember { mutableStateOf(1) } // Default moderate
    var goalIndex by remember { mutableStateOf(1) } // Default maintain
    var calculated by remember { mutableStateOf(false) }

    var bmrResult by remember { mutableStateOf("0 kcal") }
    var maintenanceResult by remember { mutableStateOf("0 kcal") }
    var targetResult by remember { mutableStateOf("0 kcal") }

    val activityLevels = listOf(
        "Sedentary (Little/no exercise)" to 1.2,
        "Lightly Active (1-3 days/wk)" to 1.375,
        "Moderately Active (3-5 days/wk)" to 1.55,
        "Very Active (6-7 days/wk)" to 1.725,
        "Super Active (Hard physical job)" to 1.9
    )

    val goals = listOf(
        "Lose Weight (-500 kcal)" to -500.0,
        "Maintain Weight" to 0.0,
        "Gain Weight (+500 kcal)" to 500.0
    )

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Calorie Calculator",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Gender Selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (genderIsMale) MaterialTheme.colorScheme.primary else Color(0x1F8896B0))
                            .clickable { genderIsMale = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Male",
                            color = if (genderIsMale) Color.Black else MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (!genderIsMale) MaterialTheme.colorScheme.primary else Color(0x1F8896B0))
                            .clickable { genderIsMale = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Female",
                            color = if (!genderIsMale) Color.Black else MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Metric Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isMetric) MaterialTheme.colorScheme.secondary else Color(0x1F8896B0))
                            .clickable { isMetric = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Metric (kg / cm)",
                            color = if (isMetric) Color.White else MaterialTheme.colorScheme.onBackground,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (!isMetric) MaterialTheme.colorScheme.secondary else Color(0x1F8896B0))
                            .clickable { isMetric = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Imperial (lbs / in)",
                            color = if (!isMetric) Color.White else MaterialTheme.colorScheme.onBackground,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                CalcTextField(
                    value = age,
                    onValueChange = { age = it },
                    label = "Age (Years)",
                    placeholder = "e.g. 28",
                    testTag = "calorie_age"
                )

                CalcTextField(
                    value = weight,
                    onValueChange = { weight = it },
                    label = if (isMetric) "Weight (kg)" else "Weight (lbs)",
                    placeholder = if (isMetric) "e.g. 75" else "e.g. 165",
                    testTag = "calorie_weight"
                )

                CalcTextField(
                    value = height,
                    onValueChange = { height = it },
                    label = if (isMetric) "Height (cm)" else "Height (inches)",
                    placeholder = if (isMetric) "e.g. 180" else "e.g. 71",
                    testTag = "calorie_height"
                )

                // Activity Level Dropdown Simulation
                Text(
                    "Activity Level",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    activityLevels.forEachIndexed { idx, (label, _) ->
                        val isSelected = activityIndex == idx
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(38.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color(0x0A8896B0))
                                .border(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(8.dp))
                                .clickable { activityIndex = idx }
                                .padding(horizontal = 12.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                label,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                // Goal Selection
                Text(
                    "Target Goal",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    goals.forEachIndexed { idx, (label, _) ->
                        val isSelected = goalIndex == idx
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) MaterialTheme.colorScheme.primary else Color(0x1F8896B0))
                                .clickable { goalIndex = idx },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                label,
                                color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onBackground,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 2
                            )
                        }
                    }
                }

                GradientButton(
                    text = "Calculate Calories",
                    onClick = {
                        val a = age.toDoubleOrNull() ?: 0.0
                        val wRaw = weight.toDoubleOrNull() ?: 0.0
                        val hRaw = height.toDoubleOrNull() ?: 0.0

                        if (a > 0 && wRaw > 0 && hRaw > 0) {
                            val wKg = if (isMetric) wRaw else wRaw / 2.20462
                            val hCm = if (isMetric) hRaw else hRaw * 2.54

                            // Mifflin-St Jeor equation
                            val bmr = if (genderIsMale) {
                                (10 * wKg) + (6.25 * hCm) - (5 * a) + 5
                            } else {
                                (10 * wKg) + (6.25 * hCm) - (5 * a) - 161
                            }

                            val factor = activityLevels[activityIndex].second
                            val maintenance = bmr * factor
                            val target = maintenance + goals[goalIndex].second

                            bmrResult = String.format(Locale.US, "%,.0f kcal/day", bmr)
                            maintenanceResult = String.format(Locale.US, "%,.0f kcal/day", maintenance)
                            targetResult = String.format(Locale.US, "%,.0f kcal/day", target)
                            calculated = true
                        }
                    },
                    testTag = "calorie_calc_btn"
                )
            }
        }

        if (calculated) {
            ResultCard(
                title = "Daily Caloric Target",
                mainValue = targetResult,
                subDetails = listOf(
                    "Basal Metabolic Rate (BMR)" to bmrResult,
                    "Maintenance Calories (TDEE)" to maintenanceResult,
                    "Current Goal Status" to goals[goalIndex].first
                ),
                badgeText = "Mifflin-St Jeor",
                badgeColor = ColorGreen
            )
        }

        FormulaBox(
            formula = "BMR (Men) = 10W + 6.25H - 5A + 5\nBMR (Women) = 10W + 6.25H - 5A - 161",
            description = "Calculated via Mifflin-St Jeor and scaled by the Harris-Benedict physical activity multiplier."
        )

        FaqSection(
            faqs = listOf(
                "What is BMR vs TDEE?" to "BMR (Basal Metabolic Rate) is the baseline calories burned just staying alive at rest. TDEE (Total Daily Energy Expenditure) is your actual calories burned including physical activity.",
                "How much of a calorie deficit is safe?" to "A safe calorie deficit is typically 300 to 500 kcal per day, which translates to losing roughly 0.5 to 1 pound of fat per week."
            )
        )
    }
}

@Composable
fun AgeCalculatorScreen() {
    var dobDay by remember { mutableStateOf("") }
    var dobMonth by remember { mutableStateOf("") }
    var dobYear by remember { mutableStateOf("") }

    var targetDay by remember { mutableStateOf("") }
    var targetMonth by remember { mutableStateOf("") }
    var targetYear by remember { mutableStateOf("") }

    var calculated by remember { mutableStateOf(false) }

    var summaryAge by remember { mutableStateOf("") }
    var nextBirthdayDays by remember { mutableStateOf("") }
    var totalMonthsLived by remember { mutableStateOf("") }
    var totalWeeksLived by remember { mutableStateOf("") }
    var totalDaysLived by remember { mutableStateOf("") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Age Calculator",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "Date of Birth",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        CalcTextField(
                            value = dobDay,
                            onValueChange = { dobDay = it },
                            label = "Day",
                            placeholder = "DD",
                            testTag = "age_dob_day"
                        )
                    }
                    Box(modifier = Modifier.weight(1.2f)) {
                        CalcTextField(
                            value = dobMonth,
                            onValueChange = { dobMonth = it },
                            label = "Month (1-12)",
                            placeholder = "MM",
                            testTag = "age_dob_month"
                        )
                    }
                    Box(modifier = Modifier.weight(1.4f)) {
                        CalcTextField(
                            value = dobYear,
                            onValueChange = { dobYear = it },
                            label = "Year",
                            placeholder = "YYYY",
                            testTag = "age_dob_year"
                        )
                    }
                }

                Text(
                    "Age at Reference Date (Default: Today)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        CalcTextField(
                            value = targetDay,
                            onValueChange = { targetDay = it },
                            label = "Day",
                            placeholder = "DD (Optional)",
                            testTag = "age_ref_day"
                        )
                    }
                    Box(modifier = Modifier.weight(1.2f)) {
                        CalcTextField(
                            value = targetMonth,
                            onValueChange = { targetMonth = it },
                            label = "Month",
                            placeholder = "MM (Optional)",
                            testTag = "age_ref_month"
                        )
                    }
                    Box(modifier = Modifier.weight(1.4f)) {
                        CalcTextField(
                            value = targetYear,
                            onValueChange = { targetYear = it },
                            label = "Year",
                            placeholder = "YYYY (Optional)",
                            testTag = "age_ref_year"
                        )
                    }
                }

                GradientButton(
                    text = "Calculate Age",
                    onClick = {
                        val dDay = dobDay.toIntOrNull() ?: 0
                        val dMonth = dobMonth.toIntOrNull() ?: 0
                        val dYear = dobYear.toIntOrNull() ?: 0

                        if (dDay in 1..31 && dMonth in 1..12 && dYear > 1800) {
                            try {
                                val dobDate = LocalDate.of(dYear, dMonth, dDay)
                                
                                val tDay = targetDay.toIntOrNull() ?: LocalDate.now().dayOfMonth
                                val tMonth = targetMonth.toIntOrNull() ?: LocalDate.now().monthValue
                                val tYear = targetYear.toIntOrNull() ?: LocalDate.now().year
                                val targetDate = LocalDate.of(tYear, tMonth, tDay)

                                if (!targetDate.isBefore(dobDate)) {
                                    val period = Period.between(dobDate, targetDate)
                                    summaryAge = "${period.years} Years, ${period.months} Months, ${period.days} Days"

                                    // Next Birthday calculations
                                    val nextBirthdayYear = if (targetDate.withMonth(dobDate.monthValue).withDayOfMonth(dobDate.dayOfMonth).isBefore(targetDate)) {
                                        targetDate.year + 1
                                    } else {
                                        targetDate.year
                                    }
                                    
                                    val nextBirthdayDate = LocalDate.of(nextBirthdayYear, dobDate.monthValue, dobDate.dayOfMonth)
                                    val daysUntil = ChronoUnit.DAYS.between(targetDate, nextBirthdayDate)
                                    nextBirthdayDays = "$daysUntil Days"

                                    // Lifespan metrics
                                    totalMonthsLived = String.format(Locale.US, "%,d Months", ChronoUnit.MONTHS.between(dobDate, targetDate))
                                    totalWeeksLived = String.format(Locale.US, "%,d Weeks", ChronoUnit.WEEKS.between(dobDate, targetDate))
                                    totalDaysLived = String.format(Locale.US, "%,d Days", ChronoUnit.DAYS.between(dobDate, targetDate))

                                    calculated = true
                                }
                            } catch (e: Exception) {
                                // Invalid dates parsed (e.g. Feb 31st)
                            }
                        }
                    },
                    testTag = "age_calc_btn"
                )
            }
        }

        if (calculated) {
            ResultCard(
                title = "Current Age",
                mainValue = summaryAge,
                subDetails = listOf(
                    "Days to Next Birthday" to nextBirthdayDays,
                    "Total Months Lived" to totalMonthsLived,
                    "Total Weeks Lived" to totalWeeksLived,
                    "Total Days Lived" to totalDaysLived
                ),
                badgeText = "Precise Age",
                badgeColor = ColorGreen
            )
        }

        FormulaBox(
            formula = "Period = Duration between Dates",
            description = "Resolves calendar intervals taking leap years, varying month lengths, and exact day boundaries into account."
        )

        FaqSection(
            faqs = listOf(
                "Why is reference date helpful?" to "It allows you to compute how old you were at a historic milestone, or how old you will be at a future event.",
                "How does the birthday tracker calculate days?" to "It tracks the current date against the next calendar recurrence of your birth month and day, adjusting for leap years."
            )
        )
    }
}
