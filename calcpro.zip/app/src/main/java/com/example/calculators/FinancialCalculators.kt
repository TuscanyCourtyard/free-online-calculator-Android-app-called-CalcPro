package com.example.calculators

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CalcTextField
import com.example.ui.components.FaqSection
import com.example.ui.components.FormulaBox
import com.example.ui.components.GlassCard
import com.example.ui.components.GradientButton
import com.example.ui.components.ResultCard
import com.example.ui.theme.ColorAmber
import com.example.ui.theme.ColorGreen
import java.util.Locale
import kotlin.math.pow

@Composable
fun LoanCalculatorScreen() {
    var principal by remember { mutableStateOf("") }
    var interestRate by remember { mutableStateOf("") }
    var termYears by remember { mutableStateOf("") }
    var calculated by remember { mutableStateOf(false) }

    var monthlyPayment by remember { mutableStateOf("0.00") }
    var totalInterest by remember { mutableStateOf("0.00") }
    var totalPayment by remember { mutableStateOf("0.00") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Loan Calculator",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CalcTextField(
                    value = principal,
                    onValueChange = { principal = it },
                    label = "Principal Loan Amount ($)",
                    placeholder = "e.g. 50000",
                    testTag = "loan_principal"
                )
                CalcTextField(
                    value = interestRate,
                    onValueChange = { interestRate = it },
                    label = "Annual Interest Rate (%)",
                    placeholder = "e.g. 5.5",
                    testTag = "loan_rate"
                )
                CalcTextField(
                    value = termYears,
                    onValueChange = { termYears = it },
                    label = "Loan Term (Years)",
                    placeholder = "e.g. 15",
                    testTag = "loan_term"
                )

                GradientButton(
                    text = "Calculate Loan",
                    onClick = {
                        val p = principal.toDoubleOrNull() ?: 0.0
                        val r = (interestRate.toDoubleOrNull() ?: 0.0) / 100 / 12
                        val n = (termYears.toDoubleOrNull() ?: 0.0) * 12

                        if (p > 0 && r > 0 && n > 0) {
                            val monthly = p * (r * (1 + r).pow(n)) / ((1 + r).pow(n) - 1)
                            val total = monthly * n
                            val interest = total - p

                            monthlyPayment = String.format(Locale.US, "$%,.2f", monthly)
                            totalInterest = String.format(Locale.US, "$%,.2f", interest)
                            totalPayment = String.format(Locale.US, "$%,.2f", total)
                            calculated = true
                        }
                    },
                    testTag = "loan_calc_btn"
                )
            }
        }

        AnimatedVisibility(visible = calculated) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                ResultCard(
                    title = "Monthly Payment",
                    mainValue = monthlyPayment,
                    subDetails = listOf(
                        "Total Principal" to String.format(Locale.US, "$%,.2f", principal.toDoubleOrNull() ?: 0.0),
                        "Total Interest" to totalInterest,
                        "Total Repayment" to totalPayment
                    ),
                    badgeText = "Amortized",
                    badgeColor = ColorGreen
                )
            }
        }

        FormulaBox(
            formula = "M = P * [r(1+r)^n] / [(1+r)^n - 1]",
            description = "Where P is the principal loan amount, r is the monthly interest rate, and n is the total number of monthly payments."
        )

        FaqSection(
            faqs = listOf(
                "What is principal?" to "Principal is the original sum of money borrowed in a loan, or put into an investment, separate from any interest accrued.",
                "How can I reduce my total interest?" to "You can reduce total interest by increasing your monthly payments, choosing a shorter term, or securing a lower interest rate."
            )
        )
    }
}

@Composable
fun EmiCalculatorScreen() {
    var loanAmount by remember { mutableStateOf("") }
    var interestRate by remember { mutableStateOf("") }
    var tenure by remember { mutableStateOf("") }
    var isYears by remember { mutableStateOf(true) }
    var calculated by remember { mutableStateOf(false) }

    var emi by remember { mutableStateOf("0.00") }
    var interestPayable by remember { mutableStateOf("0.00") }
    var totalAmount by remember { mutableStateOf("0.00") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "EMI Calculator",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CalcTextField(
                    value = loanAmount,
                    onValueChange = { loanAmount = it },
                    label = "Loan Amount",
                    placeholder = "e.g. 10000",
                    testTag = "emi_amount"
                )
                CalcTextField(
                    value = interestRate,
                    onValueChange = { interestRate = it },
                    label = "Annual Interest Rate (%)",
                    placeholder = "e.g. 8.5",
                    testTag = "emi_rate"
                )
                CalcTextField(
                    value = tenure,
                    onValueChange = { tenure = it },
                    label = "Tenure",
                    placeholder = if (isYears) "e.g. 5 (Years)" else "e.g. 60 (Months)",
                    testTag = "emi_tenure"
                )

                // Years/Months Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isYears) MaterialTheme.colorScheme.primary else Color(0x1F8896B0))
                            .clickable { isYears = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Years",
                            color = if (isYears) Color.Black else MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (!isYears) MaterialTheme.colorScheme.primary else Color(0x1F8896B0))
                            .clickable { isYears = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Months",
                            color = if (!isYears) Color.Black else MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                GradientButton(
                    text = "Calculate EMI",
                    onClick = {
                        val p = loanAmount.toDoubleOrNull() ?: 0.0
                        val r = (interestRate.toDoubleOrNull() ?: 0.0) / 12 / 100
                        val t = tenure.toDoubleOrNull() ?: 0.0
                        val n = if (isYears) t * 12 else t

                        if (p > 0 && r > 0 && n > 0) {
                            val calculatedEmi = p * r * (1 + r).pow(n) / ((1 + r).pow(n) - 1)
                            val total = calculatedEmi * n
                            val interest = total - p

                            emi = String.format(Locale.US, "$%,.2f", calculatedEmi)
                            interestPayable = String.format(Locale.US, "$%,.2f", interest)
                            totalAmount = String.format(Locale.US, "$%,.2f", total)
                            calculated = true
                        }
                    },
                    testTag = "emi_calc_btn"
                )
            }
        }

        if (calculated) {
            ResultCard(
                title = "Monthly EMI",
                mainValue = emi,
                subDetails = listOf(
                    "Total Interest" to interestPayable,
                    "Total Repayment" to totalAmount
                ),
                badgeText = "Reducing Rate",
                badgeColor = ColorGreen
            )
        }

        FormulaBox(
            formula = "EMI = P * r * (1+r)^n / [(1+r)^n - 1]",
            description = "P is Principal, r is monthly rate, n is tenure in months."
        )

        FaqSection(
            faqs = listOf(
                "What is EMI?" to "Equated Monthly Installment (EMI) is a fixed payment amount made by a borrower to a lender at a specified date each calendar month.",
                "How does reducing interest work?" to "In a reducing balance method, interest is calculated on the remaining loan principal outstanding at the end of each period, so the interest component declines over time."
            )
        )
    }
}

@Composable
fun SalaryCalculatorScreen() {
    var grossSalary by remember { mutableStateOf("") }
    var allowances by remember { mutableStateOf("") }
    var deductions by remember { mutableStateOf("") }
    var calculated by remember { mutableStateOf(false) }

    var netSalary by remember { mutableStateOf("0.00") }
    var monthlyNet by remember { mutableStateOf("0.00") }
    var weeklyNet by remember { mutableStateOf("0.00") }
    var hourlyNet by remember { mutableStateOf("0.00") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Salary Calculator",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CalcTextField(
                    value = grossSalary,
                    onValueChange = { grossSalary = it },
                    label = "Gross Annual Salary ($)",
                    placeholder = "e.g. 75000",
                    testTag = "salary_gross"
                )
                CalcTextField(
                    value = allowances,
                    onValueChange = { allowances = it },
                    label = "Annual Allowances / Bonuses ($)",
                    placeholder = "e.g. 5000 (Optional)",
                    testTag = "salary_allowances"
                )
                CalcTextField(
                    value = deductions,
                    onValueChange = { deductions = it },
                    label = "Annual Deductions / Taxes ($)",
                    placeholder = "e.g. 15000 (Optional)",
                    testTag = "salary_deductions"
                )

                GradientButton(
                    text = "Calculate Take-Home Pay",
                    onClick = {
                        val gross = grossSalary.toDoubleOrNull() ?: 0.0
                        val allow = allowances.toDoubleOrNull() ?: 0.0
                        val deduct = deductions.toDoubleOrNull() ?: 0.0

                        val net = gross + allow - deduct
                        if (net >= 0) {
                            netSalary = String.format(Locale.US, "$%,.2f", net)
                            monthlyNet = String.format(Locale.US, "$%,.2f", net / 12)
                            weeklyNet = String.format(Locale.US, "$%,.2f", net / 52)
                            // Assuming standard 2080 working hours per year (40 hours/week * 52 weeks)
                            hourlyNet = String.format(Locale.US, "$%,.2f", net / 2080)
                            calculated = true
                        }
                    },
                    testTag = "salary_calc_btn"
                )
            }
        }

        if (calculated) {
            ResultCard(
                title = "Net Annual Salary",
                mainValue = netSalary,
                subDetails = listOf(
                    "Monthly Net Pay" to monthlyNet,
                    "Weekly Net Pay" to weeklyNet,
                    "Estimated Hourly (Net)" to hourlyNet
                ),
                badgeText = "Take-Home",
                badgeColor = ColorGreen
            )
        }

        FormulaBox(
            formula = "Net Salary = Gross Salary + Allowances - Deductions",
            description = "Provides a breakdown across standard periods (monthly, weekly, and hourly based on a standard 2080-hour work year)."
        )

        FaqSection(
            faqs = listOf(
                "What is Gross Salary?" to "Gross salary is the total pay before any taxes, deductions, or insurance costs are taken out by your employer.",
                "What does 'Net Salary' represent?" to "Net salary, or take-home pay, is the actual amount that is transferred to your bank account after all deductions and taxes."
            )
        )
    }
}

@Composable
fun MortgageCalculatorScreen() {
    var homeValue by remember { mutableStateOf("") }
    var downPayment by remember { mutableStateOf("") }
    var interestRate by remember { mutableStateOf("") }
    var termYears by remember { mutableStateOf("") }
    var propertyTax by remember { mutableStateOf("") }
    var homeInsurance by remember { mutableStateOf("") }
    var calculated by remember { mutableStateOf(false) }

    var monthlyTotal by remember { mutableStateOf("0.00") }
    var monthlyPI by remember { mutableStateOf("0.00") }
    var monthlyTax by remember { mutableStateOf("0.00") }
    var monthlyIns by remember { mutableStateOf("0.00") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Mortgage Calculator",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CalcTextField(
                    value = homeValue,
                    onValueChange = { homeValue = it },
                    label = "Home Value ($)",
                    placeholder = "e.g. 350000",
                    testTag = "mortgage_home"
                )
                CalcTextField(
                    value = downPayment,
                    onValueChange = { downPayment = it },
                    label = "Down Payment ($)",
                    placeholder = "e.g. 70000",
                    testTag = "mortgage_down"
                )
                CalcTextField(
                    value = interestRate,
                    onValueChange = { interestRate = it },
                    label = "Annual Interest Rate (%)",
                    placeholder = "e.g. 6.5",
                    testTag = "mortgage_rate"
                )
                CalcTextField(
                    value = termYears,
                    onValueChange = { termYears = it },
                    label = "Term (Years)",
                    placeholder = "e.g. 30",
                    testTag = "mortgage_term"
                )
                CalcTextField(
                    value = propertyTax,
                    onValueChange = { propertyTax = it },
                    label = "Annual Property Tax ($)",
                    placeholder = "e.g. 3000 (Optional)",
                    testTag = "mortgage_tax"
                )
                CalcTextField(
                    value = homeInsurance,
                    onValueChange = { homeInsurance = it },
                    label = "Annual Home Insurance ($)",
                    placeholder = "e.g. 1200 (Optional)",
                    testTag = "mortgage_insurance"
                )

                GradientButton(
                    text = "Calculate Mortgage",
                    onClick = {
                        val value = homeValue.toDoubleOrNull() ?: 0.0
                        val down = downPayment.toDoubleOrNull() ?: 0.0
                        val p = value - down
                        val r = (interestRate.toDoubleOrNull() ?: 0.0) / 100 / 12
                        val n = (termYears.toDoubleOrNull() ?: 0.0) * 12
                        val taxAnnual = propertyTax.toDoubleOrNull() ?: 0.0
                        val insAnnual = homeInsurance.toDoubleOrNull() ?: 0.0

                        if (p > 0 && r > 0 && n > 0) {
                            val pi = p * (r * (1 + r).pow(n)) / ((1 + r).pow(n) - 1)
                            val tax = taxAnnual / 12
                            val ins = insAnnual / 12
                            val total = pi + tax + ins

                            monthlyPI = String.format(Locale.US, "$%,.2f", pi)
                            monthlyTax = String.format(Locale.US, "$%,.2f", tax)
                            monthlyIns = String.format(Locale.US, "$%,.2f", ins)
                            monthlyTotal = String.format(Locale.US, "$%,.2f", total)
                            calculated = true
                        }
                    },
                    testTag = "mortgage_calc_btn"
                )
            }
        }

        if (calculated) {
            ResultCard(
                title = "Total Monthly Payment",
                mainValue = monthlyTotal,
                subDetails = listOf(
                    "Principal & Interest" to monthlyPI,
                    "Monthly Property Tax" to monthlyTax,
                    "Monthly Insurance" to monthlyIns,
                    "Total Loan Amount" to String.format(Locale.US, "$%,.2f", (homeValue.toDoubleOrNull() ?: 0.0) - (downPayment.toDoubleOrNull() ?: 0.0))
                ),
                badgeText = "PITI Payment",
                badgeColor = ColorAmber
            )
        }

        FormulaBox(
            formula = "Payment = P & I + Tax/12 + Ins/12",
            description = "Calculates Principal & Interest using standard amortization on the net loan amount, then aggregates escrow items."
        )

        FaqSection(
            faqs = listOf(
                "What is PITI?" to "PITI stands for Principal, Interest, Taxes, and Insurance. These are the four basic components of a monthly mortgage payment.",
                "How much should my down payment be?" to "Traditionally, 20% down avoids Private Mortgage Insurance (PMI), but many loans allow down payments as low as 3% to 5%."
            )
        )
    }
}

@Composable
fun InterestCalculatorScreen() {
    var principal by remember { mutableStateOf("") }
    var interestRate by remember { mutableStateOf("") }
    var termYears by remember { mutableStateOf("") }
    var isCompound by remember { mutableStateOf(false) }
    var compoundFrequency by remember { mutableStateOf(12) } // default monthly
    var calculated by remember { mutableStateOf(false) }

    var interestEarned by remember { mutableStateOf("0.00") }
    var totalValue by remember { mutableStateOf("0.00") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Interest Calculator",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CalcTextField(
                    value = principal,
                    onValueChange = { principal = it },
                    label = "Principal Amount ($)",
                    placeholder = "e.g. 10000",
                    testTag = "interest_principal"
                )
                CalcTextField(
                    value = interestRate,
                    onValueChange = { interestRate = it },
                    label = "Annual Interest Rate (%)",
                    placeholder = "e.g. 6.0",
                    testTag = "interest_rate"
                )
                CalcTextField(
                    value = termYears,
                    onValueChange = { termYears = it },
                    label = "Term (Years)",
                    placeholder = "e.g. 5",
                    testTag = "interest_term"
                )

                // Simple / Compound Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (!isCompound) MaterialTheme.colorScheme.primary else Color(0x1F8896B0))
                            .clickable { isCompound = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Simple Interest",
                            color = if (!isCompound) Color.Black else MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isCompound) MaterialTheme.colorScheme.primary else Color(0x1F8896B0))
                            .clickable { isCompound = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Compound",
                            color = if (isCompound) Color.Black else MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }

                if (isCompound) {
                    Text(
                        "Compounding Frequency",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            "Monthly" to 12,
                            "Quarterly" to 4,
                            "Annually" to 1
                        ).forEach { (label, freq) ->
                            val selected = compoundFrequency == freq
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(36.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (selected) MaterialTheme.colorScheme.secondary else Color(0x1F8896B0))
                                    .clickable { compoundFrequency = freq },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    label,
                                    color = if (selected) Color.White else MaterialTheme.colorScheme.onBackground,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                GradientButton(
                    text = "Calculate Interest",
                    onClick = {
                        val p = principal.toDoubleOrNull() ?: 0.0
                        val r = (interestRate.toDoubleOrNull() ?: 0.0) / 100
                        val t = termYears.toDoubleOrNull() ?: 0.0

                        if (p > 0 && r > 0 && t > 0) {
                            if (!isCompound) {
                                val interest = p * r * t
                                val total = p + interest
                                interestEarned = String.format(Locale.US, "$%,.2f", interest)
                                totalValue = String.format(Locale.US, "$%,.2f", total)
                            } else {
                                val n = compoundFrequency.toDouble()
                                val total = p * (1 + r / n).pow(n * t)
                                val interest = total - p
                                interestEarned = String.format(Locale.US, "$%,.2f", interest)
                                totalValue = String.format(Locale.US, "$%,.2f", total)
                            }
                            calculated = true
                        }
                    },
                    testTag = "interest_calc_btn"
                )
            }
        }

        if (calculated) {
            ResultCard(
                title = "Total Interest Earned",
                mainValue = interestEarned,
                subDetails = listOf(
                    "Principal Amount" to String.format(Locale.US, "$%,.2f", principal.toDoubleOrNull() ?: 0.0),
                    "Final Balance" to totalValue
                ),
                badgeText = if (isCompound) "Compound" else "Simple",
                badgeColor = ColorGreen
            )
        }

        FormulaBox(
            formula = if (isCompound) "A = P * (1 + r/n)^(nt)" else "I = P * r * t",
            description = "Compound interest accrues value dynamically over each frequency period. Simple interest is constant."
        )

        FaqSection(
            faqs = listOf(
                "How does compounding frequency affect growth?" to "The more frequently interest is compounded, the faster your investment grows because interest starts earning interest sooner.",
                "What is the Rule of 72?" to "A shortcut to estimate how long it takes to double an investment: Divide 72 by your annual interest rate."
            )
        )
    }
}

@Composable
fun TaxCalculatorScreen() {
    var grossIncome by remember { mutableStateOf("") }
    var deductions by remember { mutableStateOf("") }
    var calculated by remember { mutableStateOf(false) }

    var taxDue by remember { mutableStateOf("0.00") }
    var netIncome by remember { mutableStateOf("0.00") }
    var effectiveRate by remember { mutableStateOf("0.0%") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Tax Calculator",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CalcTextField(
                    value = grossIncome,
                    onValueChange = { grossIncome = it },
                    label = "Gross Income ($)",
                    placeholder = "e.g. 85000",
                    testTag = "tax_income"
                )
                CalcTextField(
                    value = deductions,
                    onValueChange = { deductions = it },
                    label = "Deductions / Exemptions ($)",
                    placeholder = "e.g. 13850 (Optional)",
                    testTag = "tax_deductions"
                )

                GradientButton(
                    text = "Calculate Income Tax",
                    onClick = {
                        val gross = grossIncome.toDoubleOrNull() ?: 0.0
                        val deduct = deductions.toDoubleOrNull() ?: 0.0
                        val taxable = (gross - deduct).coerceAtLeast(0.0)

                        // Progressive tax brackets (Simulation based on US 2024 single filer brackets)
                        val brackets = listOf(
                            11600.0 to 0.10,
                            47150.0 to 0.12,
                            100525.0 to 0.22,
                            191950.0 to 0.24,
                            243725.0 to 0.32,
                            609350.0 to 0.35,
                            Double.MAX_VALUE to 0.37
                        )

                        var tax = 0.0
                        var lastLimit = 0.0

                        for ((limit, rate) in brackets) {
                            if (taxable > limit) {
                                tax += (limit - lastLimit) * rate
                                lastLimit = limit
                            } else {
                                tax += (taxable - lastLimit) * rate
                                break
                            }
                        }

                        val net = gross - tax
                        val ratePercent = if (gross > 0) (tax / gross) * 100 else 0.0

                        taxDue = String.format(Locale.US, "$%,.2f", tax)
                        netIncome = String.format(Locale.US, "$%,.2f", net)
                        effectiveRate = String.format(Locale.US, "%.2f%%", ratePercent)
                        calculated = true
                    },
                    testTag = "tax_calc_btn"
                )
            }
        }

        if (calculated) {
            ResultCard(
                title = "Estimated Income Tax",
                mainValue = taxDue,
                subDetails = listOf(
                    "Taxable Income" to String.format(Locale.US, "$%,.2f", (grossIncome.toDoubleOrNull() ?: 0.0) - (deductions.toDoubleOrNull() ?: 0.0)),
                    "Effective Tax Rate" to effectiveRate,
                    "Net Income" to netIncome
                ),
                badgeText = "Progressive Bracket",
                badgeColor = ColorAmber
            )
        }

        FormulaBox(
            formula = "Tax = Sum(Income_in_Bracket * Bracket_Rate)",
            description = "Calculated progressively. Only income within each specific tier is taxed at that bracket's rate."
        )

        FaqSection(
            faqs = listOf(
                "What is marginal tax rate vs effective rate?" to "Marginal rate is the tax percentage applied to your last dollar of income. Effective rate is the average rate you pay across your entire gross income.",
                "How do deductions help?" to "Deductions reduce your taxable income, meaning you are taxed on a smaller total amount, which reduces your total tax bill."
            )
        )
    }
}

@Composable
fun VatCalculatorScreen() {
    var amount by remember { mutableStateOf("") }
    var vatRate by remember { mutableStateOf("") }
    var isInclusive by remember { mutableStateOf(false) }
    var calculated by remember { mutableStateOf(false) }

    var netAmount by remember { mutableStateOf("0.00") }
    var vatAmount by remember { mutableStateOf("0.00") }
    var grossAmount by remember { mutableStateOf("0.00") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "VAT Calculator",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CalcTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = "Amount",
                    placeholder = "e.g. 150.00",
                    testTag = "vat_amount"
                )
                CalcTextField(
                    value = vatRate,
                    onValueChange = { vatRate = it },
                    label = "VAT Rate (%)",
                    placeholder = "e.g. 20",
                    testTag = "vat_rate"
                )

                // Inclusive / Exclusive Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (!isInclusive) MaterialTheme.colorScheme.primary else Color(0x1F8896B0))
                            .clickable { isInclusive = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "VAT Exclusive",
                            color = if (!isInclusive) Color.Black else MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isInclusive) MaterialTheme.colorScheme.primary else Color(0x1F8896B0))
                            .clickable { isInclusive = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "VAT Inclusive",
                            color = if (isInclusive) Color.Black else MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }

                GradientButton(
                    text = "Calculate VAT",
                    onClick = {
                        val amt = amount.toDoubleOrNull() ?: 0.0
                        val rate = vatRate.toDoubleOrNull() ?: 0.0

                        if (amt > 0 && rate >= 0) {
                            if (isInclusive) {
                                val net = amt / (1 + rate / 100)
                                val vat = amt - net
                                netAmount = String.format(Locale.US, "$%,.2f", net)
                                vatAmount = String.format(Locale.US, "$%,.2f", vat)
                                grossAmount = String.format(Locale.US, "$%,.2f", amt)
                            } else {
                                val vat = amt * rate / 100
                                val gross = amt + vat
                                netAmount = String.format(Locale.US, "$%,.2f", amt)
                                vatAmount = String.format(Locale.US, "$%,.2f", vat)
                                grossAmount = String.format(Locale.US, "$%,.2f", gross)
                            }
                            calculated = true
                        }
                    },
                    testTag = "vat_calc_btn"
                )
            }
        }

        if (calculated) {
            ResultCard(
                title = "Calculated VAT",
                mainValue = vatAmount,
                subDetails = listOf(
                    "Net Amount (Before VAT)" to netAmount,
                    "Gross Amount (Total)" to grossAmount
                ),
                badgeText = if (isInclusive) "Inclusive" else "Exclusive",
                badgeColor = ColorAmber
            )
        }

        FormulaBox(
            formula = if (isInclusive) "VAT = Gross - [Gross / (1 + Rate/100)]" else "VAT = Net * Rate/100",
            description = "VAT Inclusive extracts tax from the entered amount, while Exclusive adds tax on top of the Net value."
        )

        FaqSection(
            faqs = listOf(
                "What is Value Added Tax (VAT)?" to "VAT is a consumption tax placed on a product or service whenever value is added at each stage of the supply chain, ultimately paid by the consumer.",
                "How do I extract VAT?" to "To extract VAT from an inclusive price, divide the total price by (1 + VAT rate as decimal). For instance, divide by 1.20 for 20% VAT."
            )
        )
    }
}

@Composable
fun YoutubeMoneyCalculatorScreen() {
    var dailyViews by remember { mutableStateOf("") }
    var rpmValue by remember { mutableStateOf("") }
    var ctrPercent by remember { mutableStateOf("") }
    var calculated by remember { mutableStateOf(false) }

    var dailyMin by remember { mutableStateOf("0.00") }
    var dailyMax by remember { mutableStateOf("0.00") }
    var monthlyRange by remember { mutableStateOf("$0.00 - $0.00") }
    var yearlyRange by remember { mutableStateOf("$0.00 - $0.00") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "YouTube Money",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CalcTextField(
                    value = dailyViews,
                    onValueChange = { dailyViews = it },
                    label = "Daily Views",
                    placeholder = "e.g. 10000",
                    testTag = "yt_views"
                )
                CalcTextField(
                    value = rpmValue,
                    onValueChange = { rpmValue = it },
                    label = "Average RPM / CPM ($)",
                    placeholder = "e.g. 2.50",
                    testTag = "yt_rpm"
                )
                CalcTextField(
                    value = ctrPercent,
                    onValueChange = { ctrPercent = it },
                    label = "Estimated CTR (%)",
                    placeholder = "e.g. 4.5 (Optional)",
                    testTag = "yt_ctr"
                )

                GradientButton(
                    text = "Calculate Earnings",
                    onClick = {
                        val views = dailyViews.toDoubleOrNull() ?: 0.0
                        val rpm = rpmValue.toDoubleOrNull() ?: 0.0
                        val ctrFactor = (ctrPercent.toDoubleOrNull() ?: 100.0) / 100.0

                        if (views > 0 && rpm > 0) {
                            val baseDaily = (views * rpm / 1000.0) * ctrFactor
                            val minDaily = baseDaily * 0.75
                            val maxDaily = baseDaily * 1.5

                            dailyMin = String.format(Locale.US, "$%,.2f", minDaily)
                            dailyMax = String.format(Locale.US, "$%,.2f", maxDaily)

                            monthlyRange = String.format(
                                Locale.US,
                                "$%,.2f - $%,.2f",
                                minDaily * 30.4,
                                maxDaily * 30.4
                            )
                            yearlyRange = String.format(
                                Locale.US,
                                "$%,.2f - $%,.2f",
                                minDaily * 365,
                                maxDaily * 365
                            )
                            calculated = true
                        }
                    },
                    testTag = "yt_calc_btn"
                )
            }
        }

        if (calculated) {
            ResultCard(
                title = "Estimated Daily Revenue",
                mainValue = "$dailyMin - $dailyMax",
                subDetails = listOf(
                    "Estimated Monthly" to monthlyRange,
                    "Estimated Yearly" to yearlyRange
                ),
                badgeText = "AdSense Estimate",
                badgeColor = ColorAmber
            )
        }

        FormulaBox(
            formula = "Earnings = (Views * RPM / 1000) * CTR",
            description = "RPM represents revenue per thousand impressions, adjusted by optional click-through rates (CTR) and views."
        )

        FaqSection(
            faqs = listOf(
                "What is CPM vs RPM?" to "CPM (Cost Per Mille) is the cost an advertiser pays for 1,000 ad views. RPM (Revenue Per Mille) is what you earn per 1,000 video views after YouTube's cut and non-monetized playbacks.",
                "How does video niche affect RPM?" to "RPM varies widely based on video niche, advertiser interest, and viewer geography. Finance and business niches typically yield higher RPMs than comedy or vlogs."
            )
        )
    }
}
