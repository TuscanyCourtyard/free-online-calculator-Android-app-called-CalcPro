package com.example.calculators

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CalcTextField
import com.example.ui.components.FaqSection
import com.example.ui.components.FormulaBox
import com.example.ui.components.GlassCard
import com.example.ui.components.GradientButton
import com.example.ui.components.ResultCard
import com.example.ui.theme.ColorGreen
import com.example.ui.theme.ColorRose
import java.util.Locale

data class CourseRow(
    val id: Int,
    var name: String = "",
    var credits: String = "",
    var gradePoint: Double = 4.0, // A = 4, B = 3, etc.
    var gradeLabel: String = "A"
)

@Composable
fun GpaCalculatorScreen() {
    var rows = remember {
        mutableStateMapOf<Int, CourseRow>().apply {
            put(0, CourseRow(0, "Course 1", "3", 4.0, "A"))
            put(1, CourseRow(1, "Course 2", "4", 3.0, "B"))
        }
    }
    var rowCounter by remember { mutableStateOf(2) }
    var calculated by remember { mutableStateOf(false) }

    var gpaResult by remember { mutableStateOf("0.00") }
    var totalCredits by remember { mutableStateOf("0") }
    var totalPoints by remember { mutableStateOf("0.0") }

    val scrollState = rememberScrollState()

    val grades = listOf(
        "A" to 4.0,
        "B" to 3.0,
        "C" to 2.0,
        "D" to 1.0,
        "F" to 0.0
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "GPA Calculator",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    "Enter Course Credits & Letter Grades",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )

                rows.values.forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Credits TextField
                        Box(modifier = Modifier.weight(1.2f)) {
                            OutlinedTextField(
                                value = row.credits,
                                onValueChange = {
                                    rows[row.id] = row.copy(credits = it)
                                },
                                label = { Text("Credits") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                                    unfocusedBorderColor = Color(0x338896B0)
                                )
                            )
                        }

                        // Grade Selection row
                        Row(
                            modifier = Modifier
                                .weight(2.5f)
                                .height(56.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0x0A8896B0))
                                .padding(horizontal = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            grades.forEach { (lbl, points) ->
                                val selected = row.gradeLabel == lbl
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (selected) MaterialTheme.colorScheme.primary else Color.Transparent)
                                        .clickable {
                                            rows[row.id] = row.copy(gradeLabel = lbl, gradePoint = points)
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        lbl,
                                        fontWeight = FontWeight.Bold,
                                        color = if (selected) Color.Black else MaterialTheme.colorScheme.onBackground,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }

                        // Delete button
                        IconButton(
                            onClick = {
                                if (rows.size > 1) {
                                    rows.remove(row.id)
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete Course",
                                tint = ColorRose
                            )
                        }
                    }
                }

                // Add Course Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f))
                        .clickable {
                            val id = rowCounter++
                            rows[id] = CourseRow(id, "Course $id", "", 4.0, "A")
                        },
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Row",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "Add Course",
                        color = MaterialTheme.colorScheme.secondary,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                GradientButton(
                    text = "Calculate GPA",
                    onClick = {
                        var sumCredits = 0.0
                        var sumPoints = 0.0

                        rows.values.forEach { row ->
                            val c = row.credits.toDoubleOrNull() ?: 0.0
                            if (c > 0) {
                                sumCredits += c
                                sumPoints += c * row.gradePoint
                            }
                        }

                        if (sumCredits > 0) {
                            gpaResult = String.format(Locale.US, "%.2f", sumPoints / sumCredits)
                            totalCredits = String.format(Locale.US, "%.0f", sumCredits)
                            totalPoints = String.format(Locale.US, "%.1f", sumPoints)
                            calculated = true
                        }
                    },
                    testTag = "gpa_calc_btn"
                )
            }
        }

        if (calculated) {
            ResultCard(
                title = "Semester GPA",
                mainValue = gpaResult,
                subDetails = listOf(
                    "Total Weighted Credits" to totalCredits,
                    "Total Course Points" to totalPoints
                ),
                badgeText = "4.0 Scale",
                badgeColor = ColorGreen
            )
        }

        FormulaBox(
            formula = "GPA = Sum(Credits * GradePoints) / Sum(Credits)",
            description = "Credits represent course weight, and grade points correspond to Letter grades (A=4, B=3, C=2, D=1, F=0)."
        )

        FaqSection(
            faqs = listOf(
                "Does course credits affect GPA?" to "Yes. A 4-credit course has double the influence on your final GPA compared to a 2-credit course.",
                "How can I raise my GPA?" to "Focus on achieving higher grades in classes that carry more credit hours, as they have the largest impact."
            )
        )
    }
}

@Composable
fun PercentageCalculatorScreen() {
    var modeIndex by remember { mutableStateOf(0) }
    var input1 by remember { mutableStateOf("") }
    var input2 by remember { mutableStateOf("") }
    var calculated by remember { mutableStateOf(false) }

    var percentageResult by remember { mutableStateOf("0.00") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Percentage Calculator",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Mode Toggle
                listOf(
                    "What is X% of Y?" to 0,
                    "A is what % of B?" to 1,
                    "% Increase/Decrease" to 2
                ).forEach { (label, idx) ->
                    val isSelected = modeIndex == idx
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) MaterialTheme.colorScheme.primary else Color(0x0A8896B0))
                            .clickable {
                                modeIndex = idx
                                calculated = false
                            }
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            label,
                            color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                CalcTextField(
                    value = input1,
                    onValueChange = { input1 = it },
                    label = when (modeIndex) {
                        0 -> "Percentage (X)"
                        1 -> "Part Value (A)"
                        else -> "Initial Value"
                    },
                    placeholder = "e.g. 15",
                    testTag = "pct_in1"
                )

                CalcTextField(
                    value = input2,
                    onValueChange = { input2 = it },
                    label = when (modeIndex) {
                        0 -> "Whole Value (Y)"
                        1 -> "Total Value (B)"
                        else -> "New Value"
                    },
                    placeholder = "e.g. 200",
                    testTag = "pct_in2"
                )

                GradientButton(
                    text = "Calculate",
                    onClick = {
                        val v1 = input1.toDoubleOrNull() ?: 0.0
                        val v2 = input2.toDoubleOrNull() ?: 0.0

                        if (v1 != 0.0 || v2 != 0.0) {
                            percentageResult = when (modeIndex) {
                                0 -> String.format(Locale.US, "%.2f", (v1 / 100) * v2)
                                1 -> if (v2 != 0.0) String.format(Locale.US, "%.2f%%", (v1 / v2) * 100) else "0.00"
                                else -> if (v1 != 0.0) String.format(Locale.US, "%.2f%%", ((v2 - v1) / v1) * 100) else "0.00"
                            }
                            calculated = true
                        }
                    },
                    testTag = "pct_calc_btn"
                )
            }
        }

        if (calculated) {
            ResultCard(
                title = "Result",
                mainValue = percentageResult,
                badgeText = "Percentage Math",
                badgeColor = ColorGreen
            )
        }

        FormulaBox(
            formula = when (modeIndex) {
                0 -> "X% * Y = (X / 100) * Y"
                1 -> "Percentage = (A / B) * 100"
                else -> "Change = ((New - Old) / Old) * 100"
            },
            description = "Calculates simple ratios, proportional adjustments, or percentage variances in numerical sequences."
        )

        FaqSection(
            faqs = listOf(
                "How is percentage variance helpful?" to "It helps in assessing business growth margins, retail discount percentages, inflation scaling, or relative weight changes.",
                "Can a percentage variance be negative?" to "Yes. A negative output indicates a percentage decrease rather than a growth or increment."
            )
        )
    }
}

@Composable
fun DiscountCalculatorScreen() {
    var originalPrice by remember { mutableStateOf("") }
    var discountPercent by remember { mutableStateOf("") }
    var taxPercent by remember { mutableStateOf("") }
    var calculated by remember { mutableStateOf(false) }

    var finalPrice by remember { mutableStateOf("0.00") }
    var totalSavings by remember { mutableStateOf("0.00") }
    var taxAmount by remember { mutableStateOf("0.00") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Discount Calculator",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CalcTextField(
                    value = originalPrice,
                    onValueChange = { originalPrice = it },
                    label = "Original Price ($)",
                    placeholder = "e.g. 120.00",
                    testTag = "discount_price"
                )
                CalcTextField(
                    value = discountPercent,
                    onValueChange = { discountPercent = it },
                    label = "Discount Percentage (%)",
                    placeholder = "e.g. 20",
                    testTag = "discount_pct"
                )
                CalcTextField(
                    value = taxPercent,
                    onValueChange = { taxPercent = it },
                    label = "Sales Tax (%)",
                    placeholder = "e.g. 8.25 (Optional)",
                    testTag = "discount_tax"
                )

                GradientButton(
                    text = "Calculate Deal",
                    onClick = {
                        val original = originalPrice.toDoubleOrNull() ?: 0.0
                        val discount = discountPercent.toDoubleOrNull() ?: 0.0
                        val taxRate = taxPercent.toDoubleOrNull() ?: 0.0

                        if (original > 0 && discount >= 0) {
                            val savings = original * discount / 100
                            val discountedPrice = original - savings
                            val tax = discountedPrice * taxRate / 100
                            val total = discountedPrice + tax

                            finalPrice = String.format(Locale.US, "$%,.2f", total)
                            totalSavings = String.format(Locale.US, "$%,.2f", savings)
                            taxAmount = String.format(Locale.US, "$%,.2f", tax)
                            calculated = true
                        }
                    },
                    testTag = "discount_calc_btn"
                )
            }
        }

        if (calculated) {
            ResultCard(
                title = "Final Price",
                mainValue = finalPrice,
                subDetails = listOf(
                    "Original Price" to String.format(Locale.US, "$%,.2f", originalPrice.toDoubleOrNull() ?: 0.0),
                    "Your Savings" to totalSavings,
                    "Sales Tax Amount" to taxAmount
                ),
                badgeText = "You Save $totalSavings!",
                badgeColor = ColorGreen
            )
        }

        FormulaBox(
            formula = "Final = (Original - Savings) + Tax",
            description = "Savings = Original * Discount / 100. Tax is computed on the discounted subtotal."
        )

        FaqSection(
            faqs = listOf(
                "Is sales tax calculated before or after the discount?" to "In almost all jurisdictions, sales tax is computed on the final discounted price paid at checkout, not the original price.",
                "How do double discounts work?" to "Typically, double discounts are calculated sequentially: the second percentage is subtracted from the already discounted amount, rather than being added together."
            )
        )
    }
}

@Composable
fun TipCalculatorScreen() {
    var billAmount by remember { mutableStateOf("") }
    var tipPercent by remember { mutableStateOf("") }
    var numPeople by remember { mutableStateOf("1") }
    var calculated by remember { mutableStateOf(false) }

    var tipTotal by remember { mutableStateOf("0.00") }
    var billTotal by remember { mutableStateOf("0.00") }
    var tipPerPerson by remember { mutableStateOf("0.00") }
    var totalPerPerson by remember { mutableStateOf("0.00") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Tip Calculator",
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CalcTextField(
                    value = billAmount,
                    onValueChange = { billAmount = it },
                    label = "Bill Subtotal ($)",
                    placeholder = "e.g. 64.50",
                    testTag = "tip_bill"
                )
                CalcTextField(
                    value = tipPercent,
                    onValueChange = { tipPercent = it },
                    label = "Tip Percentage (%)",
                    placeholder = "e.g. 15",
                    testTag = "tip_pct"
                )
                CalcTextField(
                    value = numPeople,
                    onValueChange = { numPeople = it },
                    label = "Split (Number of People)",
                    placeholder = "1",
                    testTag = "tip_people"
                )

                GradientButton(
                    text = "Calculate Split",
                    onClick = {
                        val subtotal = billAmount.toDoubleOrNull() ?: 0.0
                        val tip = tipPercent.toDoubleOrNull() ?: 0.0
                        val split = numPeople.toIntOrNull() ?: 1

                        if (subtotal > 0 && split > 0) {
                            val computedTip = subtotal * tip / 100
                            val grandTotal = subtotal + computedTip
                            
                            tipTotal = String.format(Locale.US, "$%,.2f", computedTip)
                            billTotal = String.format(Locale.US, "$%,.2f", grandTotal)
                            tipPerPerson = String.format(Locale.US, "$%,.2f", computedTip / split)
                            totalPerPerson = String.format(Locale.US, "$%,.2f", grandTotal / split)
                            calculated = true
                        }
                    },
                    testTag = "tip_calc_btn"
                )
            }
        }

        if (calculated) {
            ResultCard(
                title = "Total Per Person",
                mainValue = totalPerPerson,
                subDetails = listOf(
                    "Total Tip" to tipTotal,
                    "Grand Total" to billTotal,
                    "Tip Per Person" to tipPerPerson
                ),
                badgeText = "Shared Bill",
                badgeColor = ColorGreen
            )
        }

        FormulaBox(
            formula = "Total = Subtotal * (1 + Tip/100)",
            description = "Calculates total tip and splices both tip and subtotal values across the specified headcount."
        )

        FaqSection(
            faqs = listOf(
                "What is a standard tipping rate?" to "Typically, 15% to 20% of the pre-tax bill subtotal is a customary tip in North American dining.",
                "How do you split tax and tip fairly?" to "You can input the pre-tax subtotal to calculate the tip, then add the tax manually or split the final credit receipt directly."
            )
        )
    }
}

@Composable
fun CurrencyConverterScreen() {
    var amount by remember { mutableStateOf("") }
    var sourceCurrency by remember { mutableStateOf("USD") }
    var targetCurrency by remember { mutableStateOf("EUR") }
    var calculated by remember { mutableStateOf(false) }
    var showRatesEditor by remember { mutableStateOf(false) }

    var resultAmount by remember { mutableStateOf("0.00") }

    // Offline base rates relative to 1 USD
    val rates = remember {
        mutableStateMapOf(
            "USD" to 1.0,
            "EUR" to 0.92,
            "GBP" to 0.79,
            "INR" to 83.50,
            "CAD" to 1.37,
            "AUD" to 1.50,
            "JPY" to 155.00,
            "CNY" to 7.25,
            "AED" to 3.67,
            "CHF" to 0.90
        )
    }

    val currencyList = rates.keys.toList()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Currency",
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.weight(1f)
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f))
                    .clickable { showRatesEditor = !showRatesEditor }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (showRatesEditor) "Close Editor" else "Edit Rates",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }

        AnimatedVisibility(visible = showRatesEditor) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0x3338BDF8), RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0x990D1220)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Configure Rates (Relative to 1 USD)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    
                    rates.keys.filter { it != "USD" }.forEach { curr ->
                        var rateVal by remember(rates[curr]) { mutableStateOf(rates[curr]?.toString() ?: "") }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "1 USD = ",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Box(modifier = Modifier.weight(1f)) {
                                OutlinedTextField(
                                    value = rateVal,
                                    onValueChange = {
                                        rateVal = it
                                        val num = it.toDoubleOrNull() ?: 0.0
                                        if (num > 0) {
                                            rates[curr] = num
                                        }
                                    },
                                    singleLine = true,
                                    label = { Text(curr) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = MaterialTheme.colorScheme.secondary,
                                        unfocusedBorderColor = Color(0x338896B0)
                                    ),
                                    modifier = Modifier.height(52.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CalcTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = "Convert Amount",
                    placeholder = "e.g. 100.00",
                    testTag = "currency_amount"
                )

                // Source selection row
                Text(
                    "Source Currency",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    currencyList.take(5).forEach { curr ->
                        val isSelected = sourceCurrency == curr
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) MaterialTheme.colorScheme.primary else Color(0x0A8896B0))
                                .clickable {
                                    sourceCurrency = curr
                                    calculated = false
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                curr,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }

                // Target selection row
                Text(
                    "Target Currency",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    currencyList.take(5).forEach { curr ->
                        val isSelected = targetCurrency == curr
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) MaterialTheme.colorScheme.secondary else Color(0x0A8896B0))
                                .clickable {
                                    targetCurrency = curr
                                    calculated = false
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                curr,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }

                GradientButton(
                    text = "Convert Currency",
                    onClick = {
                        val amt = amount.toDoubleOrNull() ?: 0.0
                        val rateSrc = rates[sourceCurrency] ?: 1.0
                        val rateTgt = rates[targetCurrency] ?: 1.0

                        if (amt > 0) {
                            // Convert to Base (USD) then to Target
                            val usdVal = amt / rateSrc
                            val finalVal = usdVal * rateTgt

                            resultAmount = String.format(Locale.US, "%,.2f %s", finalVal, targetCurrency)
                            calculated = true
                        }
                    },
                    testTag = "currency_calc_btn"
                )
            }
        }

        if (calculated) {
            ResultCard(
                title = "Converted Amount",
                mainValue = resultAmount,
                subDetails = listOf(
                    "Base Exchange Rate" to String.format(Locale.US, "1 %s = %.4f %s", sourceCurrency, (rates[targetCurrency] ?: 1.0) / (rates[sourceCurrency] ?: 1.0), targetCurrency)
                ),
                badgeText = "Fully Offline",
                badgeColor = ColorGreen
            )
        }

        FormulaBox(
            formula = "Target = (Amount / SourceRate) * TargetRate",
            description = "Converts standard or custom exchange values using secure, offline calculation ratios relative to USD."
        )

        FaqSection(
            faqs = listOf(
                "How do offline rates work?" to "Since this application operates completely offline without internet tracking, exchange rates are set locally. You can customize them manually at any time.",
                "Is it safe to use custom rates?" to "Yes. Editing rates only alters the parameters saved within your local application memory, giving you complete configuration privacy."
            )
        )
    }
}
