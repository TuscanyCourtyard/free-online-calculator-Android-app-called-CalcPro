package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = DarkPrimaryAccent,
    secondary = DarkSecondaryAccent,
    tertiary = ColorRose,
    background = DarkBackground,
    surface = DarkCardBackground,
    onBackground = DarkPrimaryText,
    onSurface = DarkPrimaryText,
    onPrimary = DarkBackground,
    onSecondary = DarkPrimaryText,
    surfaceVariant = DarkCardBackground,
    onSurfaceVariant = DarkSecondaryText
)

private val LightColorScheme = lightColorScheme(
    primary = LightPrimaryAccent,
    secondary = LightSecondaryAccent,
    tertiary = ColorRose,
    background = LightBackground,
    surface = LightCardBackground,
    onBackground = LightPrimaryText,
    onSurface = LightPrimaryText,
    onPrimary = LightBackground,
    onSecondary = LightPrimaryText,
    surfaceVariant = LightCardBackground,
    onSurfaceVariant = LightSecondaryText
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
