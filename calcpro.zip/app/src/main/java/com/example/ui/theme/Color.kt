package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Theme Colors
val DarkBackground = Color(0xFF04050A)
val DarkCardBackground = Color(0xFF0D1220)
val DarkPrimaryAccent = Color(0xFF38BDF8) // Cyan
val DarkSecondaryAccent = Color(0xFF6366F1) // Blue
val DarkPrimaryText = Color(0xFFF0F4FF)
val DarkSecondaryText = Color(0xFF8896B0)

// Light Theme Colors
val LightBackground = Color(0xFFF0F4FF)
val LightCardBackground = Color(0xFFFFFFFF)
val LightPrimaryAccent = Color(0xFF0284C7) // Darker Cyan for readability
val LightSecondaryAccent = Color(0xFF4F46E5) // Darker Blue for readability
val LightPrimaryText = Color(0xFF0F172A)
val LightSecondaryText = Color(0xFF475569)

// Semantic Colors
val ColorGreen = Color(0xFF34D399)
val ColorAmber = Color(0xFFFBBF24)
val ColorRose = Color(0xFFFB7185)
